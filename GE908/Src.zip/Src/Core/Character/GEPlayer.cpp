#include <algorithm>
#include "GEPlayer.h"
#include "BaseCharacter.h"
#include "../../Foundation/GELog.h"
#include "../../Foundation/GESaveData.h"


GEPlayer::GEPlayer()
	: BaseCharacter(0, 0, "Src/Assets/Textures/player.png", Player) {
	_hp = 100;
	_speed = 200;
}

GEPlayer::~GEPlayer() {}

void GEPlayer::loadData(GESaveData* saveData) {
	_saveData = saveData;

	int mapWorldWidth = _saveData->getMapTotalWidth();
	int mapWorldHeight = _saveData->getMapTotalHeight();

	int playerStartX = static_cast<int>((mapWorldWidth / 2.0f) - (_width / 2.0f));
	int playerStartY = static_cast<int>((mapWorldHeight / 2.0f) - (_height / 2.0f));

	setPosition(playerStartX, playerStartY);
	setMapBounds(mapWorldWidth, mapWorldHeight);
}

void GEPlayer::update(float deltaTime, bool moveUp, bool moveDown, bool moveLeft, bool moveRight) {
	float moveDelta = _speed * deltaTime;
	unsigned int moveAmount = static_cast<unsigned int>(moveDelta > 1.0f ? moveDelta : 1.0f);

	if (moveUp) _originY -= moveAmount;
	if (moveDown) _originY += moveAmount;
	if (moveLeft) _originX -= moveAmount;
	if (moveRight) _originX += moveAmount;

	int screenW = _saveData->getWindowWidth();
	int screenH = _saveData->getWindowHeight();
	if (_originX < screenW / 2) _originX = screenW / 2;
	if (_originX > (_mapWidth - screenW)) _originX = (_mapWidth - screenW);

	if (_originY < screenH / 2) _originY = screenH / 2;
	if (_originY > (_mapHeight - screenH)) _originY = (_mapHeight - screenH);
}
